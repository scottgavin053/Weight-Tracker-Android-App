package com.example.weighttrackapp;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.time.LocalDate;
import java.util.ArrayList;

public class Display extends Activity {
    private Button addWeightButton, addGoalWeight;
    private EditText uWeight, uGoalWeight;
    private TextView userGoalText;
    private String weight, goalWeight, temWeight,temGoal;
    private ArrayList<User> usersList;
    private DatabaseHelper databaseHelper;
    private RAdapter recyclerAdapter;
    private RecyclerView recyclerView;


    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);
        databaseHelper = new DatabaseHelper(Display.this);
        usersList = new ArrayList<>();      //creating recycler adapter to display database entries
        usersList = databaseHelper.readUserWeight();
        recyclerAdapter = new RAdapter(usersList, Display.this);
        recyclerView = findViewById(R.id.recyclerView);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(Display.this, RecyclerView.VERTICAL, false);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setAdapter(recyclerAdapter);

        //Edit goal weight textview to display last goal weight added
        userGoalText = findViewById(R.id.textView11);
        goalWeight = databaseHelper.readGoalWeight();
        if(goalWeight == null) {
            goalWeight = "Not entered yet";
        }
        userGoalText.setText("Goal Weight: " + goalWeight);

        //compare weight and goal weight for sms message
        temWeight = databaseHelper.readJustWeight();
        if(temWeight != null && goalWeight != null){
            if(temWeight.equals(goalWeight)){
                sendSMS();
            }
        }

        //database functions to store weight and goal weight from user input
        uWeight = findViewById(R.id.addNewWeight);
        uGoalWeight = findViewById(R.id.addGoalWeight);
        addWeightButton = findViewById(R.id.button7);
        addWeightButton.setOnClickListener(view -> {
            LocalDate uDate = LocalDate.now();
            String thisdate = uDate.toString();
            weight = uWeight.getText().toString();
            databaseHelper.insertUserWeight(weight, thisdate);
            finish();
            startActivity(getIntent());
        });
        addGoalWeight = findViewById(R.id.button9);
        addGoalWeight.setOnClickListener(view -> {
            String goalWeight =  uGoalWeight.getText().toString();
            databaseHelper.insertUserGoalWeight(goalWeight);
            finish();
            startActivity(getIntent());
        });
    }

    protected void sendSMS() {  //function to check for user permission and send sms when goal weight reached
        String phoneNo = "16505551212";
        String SMS = "Goal Weight Reached!";
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNo, null, SMS, null, null );
            Toast.makeText(this, "Messages sent", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Failed to send message", Toast.LENGTH_SHORT).show();
        }
    }
}
