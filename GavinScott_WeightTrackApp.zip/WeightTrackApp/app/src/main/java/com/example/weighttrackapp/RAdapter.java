package com.example.weighttrackapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class RAdapter extends RecyclerView.Adapter<com.example.weighttrackapp.RAdapter.MyViewHolder>{
    private ArrayList<User> usersList;
    private Context context;
    private CardView mCardView;
    private Button deleteButton;


    public RAdapter(ArrayList<User> usersList, Context context) {
        this.usersList = usersList;
        this.context = context;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        private TextView weightText,idText, dateText;
        public MyViewHolder(@NonNull View view) {
            super(view);
            mCardView = view.findViewById(R.id.cardWeight);
            weightText = view.findViewById(R.id.textView7);
            idText = view.findViewById(R.id.textView6);
            dateText = view.findViewById(R.id.textView8);
            deleteButton = view.findViewById(R.id.button6);
        }}


    @NonNull
    @Override
    public RAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item, parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull RAdapter.MyViewHolder holder, int position) {
        User user = usersList.get(position);
        holder.idText.setText(user.getId());
        holder.weightText.setText(user.getWeight());
        holder.dateText.setText(user.getDate());
    }

    @Override
    public int getItemCount() {
        return usersList.size();
    }
}
