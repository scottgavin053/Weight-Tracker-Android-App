package com.example.weighttrackapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {
    Button loginButton, newUserButton;
    EditText uLogin, uPassword;
    String userName, passWord;
    DatabaseHelper weightDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        weightDatabase = new DatabaseHelper(MainActivity.this);      //database call

        uLogin = (EditText) findViewById(R.id.editUsername);        //login with existing credentials
        uPassword = (EditText) findViewById(R.id.editTextTextPassword);

        loginButton = findViewById(R.id.button); // login with existing credential
        loginButton.setOnClickListener(view -> {
            userName = uLogin.getText().toString();
            passWord = uPassword.getText().toString();
            if (userName.equals("")||passWord.equals("")) {
                Toast.makeText(MainActivity.this, "Please enter all fields",Toast.LENGTH_SHORT).show();
            }
            else {
                Boolean checkuserpass = weightDatabase.checkUserPassword(userName,passWord);
                if (checkuserpass == true) {
                    Toast.makeText(MainActivity.this,"Successfully signed in",Toast.LENGTH_SHORT).show();
                    switchActivitiesToPermission();
                }else {
                    Toast.makeText(MainActivity.this, "Invalid Credentials",Toast.LENGTH_SHORT).show();
                }
            }
        }
        );

        //new login button brings user to new login activity
        newUserButton = findViewById(R.id.button2);
        newUserButton.setOnClickListener(view -> switchActivitiesToSignUp());
    }

    private void switchActivitiesToPermission() {       //switch to permission acitivity
        Intent switchActivityIntent = new Intent(this, Permission.class);
        startActivity(switchActivityIntent);
    }
    private void switchActivitiesToSignUp() {           //switch to signup activity
        Intent switchActivityIntent = new Intent(this, Signup.class);
        startActivity(switchActivityIntent);
    }

}