package com.example.weighttrackapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "weight.db";
    private static final int VERSION = 1;
    private static final String TABLE1 = "userTable";
    private static final String TABLE2 = "addWeightTable";
    private static final String TABLE3 = "goalWeightTable";
    private static final String ID_COL = "id";
    private static final String COLUMN_NAME_USERNAME = "username";
    private static final String COLUMN_NAME_PASSWORD = "password";
    private static final String COLUMN_NAME_DATE = "date";
    private static final String COLUMN_NAME_WEIGHT = "weight";
    private static final String COLUMN_NAME_GOALWEIGHT = "goalWeight";
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {       //create database and tables
        String query = "CREATE TABLE "+ TABLE1+ " ("
                + COLUMN_NAME_USERNAME + " TEXT PRIMARY KEY, "
                + COLUMN_NAME_PASSWORD + " TEXT)";
        db.execSQL(query);

        String query2 = "CREATE TABLE " +TABLE2+ " ("
                + ID_COL + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_NAME_WEIGHT + " TEXT,"
                + COLUMN_NAME_DATE + " TEXT)";
        db.execSQL(query2);

        String query3 = "CREATE TABLE " +TABLE3+ " ("
                + ID_COL + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_NAME_GOALWEIGHT + " TEXT)";
        db.execSQL(query3);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {  //drop existing table
        db.execSQL("DROP TABLE IF EXISTS " + TABLE1 + TABLE2 + TABLE3);
        onCreate(db);
    }

    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onUpgrade(db, oldVersion, newVersion);
    }

    //create method of CRUD operations

    //get writeable database to make new user
    public Boolean insertNewUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("username" ,username);
        values.put("password",password);
        long newRowId = db.insert(TABLE1,null,values);
        return newRowId != -1;
    }

    //get writeable database to add daily weight
    public void insertUserWeight(String weight,String date) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("weight",weight);
        values.put("date",date);
        long newRowId = db.insert(TABLE2, null,values);
    }

    public void insertUserGoalWeight(String goalUWeight) {  //get writeable database to add goal weight
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("goalWeight", String.valueOf(goalUWeight));
        long newRowId = db.insert(TABLE3, null, values);
        db.close();
    }

    //Read function of CRUD

   // check for existing user and implement in insertNewUser to ensure no duplicates
    public Boolean checkUsername(String username) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("Select * from userTable where username = ?", new String[] {username});
        if (cursor.getCount() > 0) {
            return true;
        }
        else{
            return false;
        }
    }

    //check to see if username and password match records
    public Boolean checkUserPassword(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("Select * from userTable where username = ? and password = ?", new String[] {username,password});
        if(cursor.getCount()>0) {
            return true;
        }
        else {
            return false;
        }
    }

    //retrieve info for existing user
    public ArrayList<User> readUserWeight() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursorUsers = db.rawQuery("SELECT * FROM "+ TABLE2, null);
        ArrayList<User> userArrayList = new ArrayList<>();
            if(cursorUsers.moveToFirst()) {
                do {
                    userArrayList.add(new User(cursorUsers.getString(0),
                        cursorUsers.getString(1), cursorUsers.getString(2)));
                } while (cursorUsers.moveToNext()); }
        cursorUsers.close();
        return userArrayList;
    }

    //return user's most recent goal weight
    public String readGoalWeight() {
        SQLiteDatabase db = this.getReadableDatabase();
        String goalWeight = null;
        Cursor cursor = db.rawQuery("SELECT * FROM "+ TABLE3 + " ORDER BY " + ID_COL + " DESC LIMIT 1", null);
        if(cursor.moveToFirst()) {
            goalWeight = cursor.getString(1);
        }
        return goalWeight;
    }

    //returns user's most recent daily weight
    public String readJustWeight() {
        SQLiteDatabase db = this.getReadableDatabase();
        String curWeight = null;
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE2 + " ORDER BY " + ID_COL + " DESC LIMIT 1",null);
        if (cursor.moveToFirst()) {
            curWeight = cursor.getString(1);
        }
        return curWeight;
    }

    //Delete function of CRUD

    //delete user weight entry
    public void deleteWeight(String idColumn) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE2, ID_COL + " = ?", new String[] {idColumn});
    }


}