package com.example.weighttrackapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Signup extends Activity {
    EditText uUsername, uPassword, uConfirmPass;
    Button newUserButton;
    String newUsername,newPassword,newConfirmPass;
    DatabaseHelper weightDatabase;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        weightDatabase = new DatabaseHelper(this);

        uUsername = findViewById(R.id.editTextTextPersonName);       //getting login and password for new user
        uPassword = findViewById(R.id.editTextNumberPassword);
        uConfirmPass = findViewById(R.id.editTextNumberPassword2);


        //onclick checks that all fields are not null, password and confirm password match, and creates new user
        newUserButton = findViewById(R.id.button8);
        newUserButton.setOnClickListener(view -> {
            newUsername = uUsername.getText().toString();
            newPassword = uPassword.getText().toString();
            newConfirmPass = uConfirmPass.getText().toString();
            if (newUsername.isEmpty() || newPassword.isEmpty() || newConfirmPass.isEmpty()) {
                Toast.makeText(Signup.this, "Please enter all data", Toast.LENGTH_SHORT).show();
                return;
            }
            else if (!newPassword.equals(newConfirmPass)) {
                Toast.makeText(Signup.this, "Double check your password",Toast.LENGTH_SHORT).show();
            }
            else if (newPassword.equals(newConfirmPass)) {
                Boolean checkuser = weightDatabase.checkUsername(newUsername);
                if (!checkuser) {
                    Boolean addUser = weightDatabase.insertNewUser(newUsername, newPassword);
                    if(addUser) {
                        Toast.makeText(this, "User created successfully!", Toast.LENGTH_SHORT).show();
                        switchActivitiesToPermission();
                    }
                    else {
                        Toast.makeText(this, "Registration Unsuccesful", Toast.LENGTH_SHORT).show();
                    }
                }
                else {
                    Toast.makeText(this, "Username already exists, please enter a different username.", Toast.LENGTH_SHORT).show();
                }
            }
            }
        );
        }

    private void switchActivitiesToPermission() {
        Intent switchActivityIntent = new Intent(this, Permission.class);
        startActivity(switchActivityIntent);
    }
}
