package com.example.weighttrackapp;

public class User {
    private String weight;
    private String date;
    private String id;
    private String goalWeight;

    public User(String id, String weight, String date) {
        this.id = id;
        this.weight = weight;
        this.date = date;
    }

    public String getId() {
        return id;
    }

    public void setId() {
        String Id = id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public String getGoalWeight() {
        return goalWeight;
    }

    public void setGoalWeight(String goalWeight) {
        this.goalWeight = goalWeight;
    }
}
