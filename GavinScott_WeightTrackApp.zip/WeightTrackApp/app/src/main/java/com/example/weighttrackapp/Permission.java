package com.example.weighttrackapp;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;

public class Permission extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_permission);
        Button acceptP = findViewById(R.id.button3);
        Button declineP = findViewById(R.id.button4);
        acceptP.setOnClickListener(view -> {

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                    switchActivities();
                }else {
                  requestPermissions(new String[] {Manifest.permission.SEND_SMS}, 1);
                }
            }
        });
        declineP.setOnClickListener(view -> switchActivities());
    }

    private void switchActivities() {       //switch to display acitivity
        Intent switchActivityIntent = new Intent(this, Display.class);
        startActivity(switchActivityIntent);
    }





}
